import { Component } from '@angular/core';
import { AppGlobal } from './app.global';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'Ficha Electrónica de Salud';
  notificaciones = false;
  showNavbar = true;

  constructor(private global: AppGlobal, private router: Router){
    

  }
  onLogoClick(e: any) {
    debugger
  }
  onTitleClick(e: any) {
    debugger
  }
  onNotificationsClick(e: any) {
    debugger
  }
  onChangePreferences(data: any) {
    debugger
  }


}
